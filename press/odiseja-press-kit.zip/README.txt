ODISEJA – PRESS KIT

logo/horizontal, vertical, symbol: SVG (vector), PNG (transparent background), PDF.
Colours: turquoise #00B1BC, black #000000, white #FFFFFF.
Usage rules: usage-rules.pdf

NOTE: Use the symbol alone only as a decorative element.

Permission to use: wording and contact will be added.
