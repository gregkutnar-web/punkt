ODISEJA – PRESS KIT

logo/horizontal, vertical, symbol: SVG (vector), PNG (transparent background), PDF.
Colours: turquoise #00868F, black #000000, white #FFFFFF.
Usage rules: usage-rules.pdf

Permission to use: wording and contact will be added.
