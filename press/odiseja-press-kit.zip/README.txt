ODISEJA – PRESS KIT

logo/horizontal, vertical, symbol: SVG (vector), PNG (transparent background), PDF.
Colours: turquoise digital #00B1BC (SVG, PNG), turquoise print #00868F (PDF), black #000000, white #FFFFFF.
Usage rules: usage-rules.pdf

NOTE: Use the symbol alone only as a decorative element.

Permission to use: wording and contact will be added.
