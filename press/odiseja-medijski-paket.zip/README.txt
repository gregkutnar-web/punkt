ODISEJA – MEDIJSKI PAKET

logo/vodoravno, navpicno, znak: SVG (vektor), PNG (prosojno ozadje), PDF.
Barve: turkizna digitalno #00B1BC (SVG, PNG), turkizna tisk #00868F (PDF), crna #000000, bela #FFFFFF.
Pravila uporabe: pravila-uporabe.pdf

POZOR: Znak samostojno uporabljamo le kot okrasni element.

Dovoljenje za uporabo: besedilo in kontakt bosta dodana.
