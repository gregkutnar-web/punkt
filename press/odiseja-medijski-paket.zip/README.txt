ODISEJA – MEDIJSKI PAKET

logo/vodoravno, navpicno, znak: SVG (vektor), PNG (prosojno ozadje), PDF.
Barve: turkizna #00868F, crna #000000, bela #FFFFFF.
Pravila uporabe: pravila-uporabe.pdf

Dovoljenje za uporabo: besedilo in kontakt bosta dodana.
