ODISEJA – MEDIJSKI PAKET

logo/vodoravno, navpicno, znak: SVG (vektor), PNG (prosojno ozadje), PDF.
Barve: turkizna #00B1BC, crna #000000, bela #FFFFFF.
Pravila uporabe: pravila-uporabe.pdf

POZOR: Znak samostojno uporabljamo le kot okrasni element.

Dovoljenje za uporabo: besedilo in kontakt bosta dodana.
